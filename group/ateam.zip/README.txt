# NetworkVisualizer
README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. Sanat Chandran, Lecture 001,  chandran3@wisc.edu
2. Riza Hassan, Lecture 001, rhassan4@wisc.edu
3. Ye Ji Kim, Lecture 001, ykim762@wisc.edu
4. Jesus Vazquez, Lecture 001, jwvazquez@wisc.edu
5. David Yan, Lecture 002, hyan56@wisc.edu

 

Which team members were on same xteam together?
Ye Ji Kim, Jesus Vazquez from xteam 62


Other notes or comments to the grader:

[place any comments or notes that will help the grader here]
